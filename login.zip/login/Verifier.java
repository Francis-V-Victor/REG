
package login;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Verifier {
  public boolean  stringVerifier(String string){
     Boolean success=true;
          try{
             Integer.valueOf(string);
             return false;
          }catch(Exception e){
              
          }
      
      
     return success; 
  } 
   public boolean verifyage(JFrame f,String age){
      Boolean success=true;
      if(!(age.length() >=18)){
          JOptionPane.showMessageDialog(f, "Applicant Must have 18yrs And Above", "NOT ELIGIBLE", 2);
          success=false;
      }
      return success;
      
  }
  public boolean verifyidNo(JFrame f,String idNo){
      Boolean success=true;
      if(!(idNo.length() == 8)){
          JOptionPane.showMessageDialog(f, "ID Number Must Have 8 Numbers", "Invalid ID Number", 2);
          success=false;
      }
      return success;
      
  }
   public boolean verifypNo(JFrame f,String pNo){
      Boolean success=true;
      if(!(pNo.length() == 10)){
          JOptionPane.showMessageDialog(f, "Phone Number Must Have 10 Number", "Invalid Phone Number", 2);
          success=false;
      }
      return success;
      
  }
  public boolean verifyEmail(JFrame f,String Email){
      Boolean success=true;
      if(!Email.contains("@")){
          JOptionPane.showMessageDialog(f, "Email should have an @", "Invalid Email", 2);
          success=false;
      }
      return success;
      
  }
  
  public boolean verifyPassword(JFrame f,String password){
      Boolean success=true;
      if(!((password.length())>=8)){
            JOptionPane.showMessageDialog(f, "Password should have atleast 8 characters", "Weak Password", 2);
             success=false;
      }else{  
        String [] specialCharacters={".","@","~","`","#","$","%","^","&","*","(",")","-","_","=","+","[","]","{","}","|","\\","/",",","?",":",";",};
        for(String specialCharacter:specialCharacters){
            if(password.contains(specialCharacter)){
              
                return true;
            }
              
         }
        JOptionPane.showMessageDialog(f, "Password should have a special character", "Weak Password", 2);
        return false;
         
     }
      
      
     
      return success;
      
  }
  
  public boolean matchPasswords(JFrame f,String password,String cPassword){
     Boolean success=false;
     if(password.equals(cPassword)){
         return true;
     }
     JOptionPane.showMessageDialog(f, "Passwords do not match");                
     return success;
     
  }
  }
