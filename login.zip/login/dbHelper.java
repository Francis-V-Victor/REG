
package login;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;


public class dbHelper {
    Connection conn;
    dbHelper(){
        conn=getConnection();
        
    }

    private Connection getConnection() {
      try{
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/employment","root","");
        }catch(Exception e){
            e.printStackTrace();
        }
      return conn;
    }
}
