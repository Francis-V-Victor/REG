/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 *
 * @author Platoon
 */
public class jobApplication extends JFrame {

    String selectedJob = "";

    jobApplication(String username, String gender, int age, String eduLevel, int pNo, int idNo, String email, String password) {
        final String name = username;

        final JFrame k = new JFrame("JOB APPLICATION FORM");
        JLabel G = new JLabel("WELCOME FOR JOB APLLICATION");
        G.setBounds(240, 5, 200, 30);
        final JLabel g1 = new JLabel();
        g1.setBounds(120, 5, 110, 30);

        g1.setText(username);
        JLabel a1 = new JLabel("NAME");
        a1.setBounds(20, 35, 170, 30);
        final JTextField b = new JTextField();

        b.setBounds(200, 35, 350, 30);
        b.setEditable(false);
        b.setText(username);

        JLabel c = new JLabel("GENDER");
        c.setBounds(20, 70, 170, 30);
        final JTextField d = new JTextField();
        d.setBounds(200, 70, 350, 30);
        d.setEditable(false);
        d.setText(gender);

        JLabel e = new JLabel("AGE");
        e.setBounds(20, 110, 170, 30);
        final JTextField f = new JTextField();
        f.setBounds(200, 110, 350, 30);
        f.setEditable(false);
        f.setText(Integer.toString(age));

        JLabel g = new JLabel("LEVEL OF EDUCATION");
        g.setBounds(20, 150, 170, 30);
        final JTextField h = new JTextField();
        h.setBounds(200, 150, 350, 30);
        h.setEditable(false);
        h.setText(eduLevel);

        JLabel i = new JLabel("PHONE NUMBER");
        i.setBounds(20, 190, 170, 30);
        final JTextField j = new JTextField();
        j.setBounds(200, 190, 350, 30);
        j.setEditable(false);
        j.setText(Integer.toString(pNo));

        JLabel l = new JLabel("ID NUMBER");
        l.setBounds(20, 230, 170, 30);
        final JTextField m = new JTextField();
        m.setBounds(200, 230, 350, 30);
        m.setEditable(false);
        m.setText(Integer.toString(idNo));

        final JLabel n = new JLabel("EMAIL");
        n.setBounds(20, 270, 170, 30);
        final JTextField o = new JTextField();
        o.setEditable(false);
        o.setText(email);
        o.setBounds(200, 270, 350, 30);
        JLabel job = new JLabel("JOBS AVAILABLE");
        job.setBounds(120, 300, 170, 30);

        String[] avJobs = {"SECURITY GUARD", "LIBRARIANS", "CHEF", "LECTURER", "CLEANER", "TECHNICIAN"};
        // final  JComboBox jobApplied=new JComboBox(avJobs);
        final JComboBox<String> jobApplied = new JComboBox<String>(new String[]{"--select job--", "SECURITY GUARD", "LIBRARIANS", "CHEF", "LECTURER", "CLEANER", "TECHNICIAN"});
        jobApplied.setBounds(100, 330, 170, 30);
        jobApplied.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                selectedJob = (String) jobApplied.getSelectedItem();
                JOptionPane.showMessageDialog(k, "Selected " + selectedJob, "selection", 1);

            }

        }
        );

        JButton u = new JButton("SUBMIT");
        u.setBounds(350, 500, 100, 30);
        JButton y = new JButton("GO BACK");
        y.setBounds(350, 550, 100, 30);
        y.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent y) {
                k.dispose();

            }
        });

        u.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent y) {

                if (!selectedJob.isEmpty() && !(selectedJob.equals("--select job--"))) {
                    try {
                        Connection conn;
                        dbHelper db = new dbHelper();
                        conn = db.conn;
                        String query = "UPDATE  members SET Job=? WHERE Name=?";
                        PreparedStatement stm = conn.prepareStatement(query);
                        stm.setString(1, selectedJob);

                        stm.setString(2, name);
                        int rows_affected = stm.executeUpdate();
                        if (rows_affected > 0) {
                            k.dispose();

                            JOptionPane.showMessageDialog(k, "WAIT FOR EMAIL MESSAGE LATER!", "Application successful", 1);
                            JOptionPane.showMessageDialog(k, "FOR MORE INFOMATION CALL 0722666888!", "CUSTOMER CARE LINE 0793841592", 1);
                        } else {
                            JOptionPane.showMessageDialog(k, "Please try again!", "Application Failed", 0);
                        }

                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(k, "Please try again!", "Job Application Failed", 0);
                        e.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(k, "Please select a job!", "No job selected", 0);

                }
            }
        });

//    fetchData();
        k.add(G);
        k.add(g1);
        k.add(a1);
        k.add(b);
        k.add(c);
        k.add(d);
        k.add(e);
        k.add(f);
        k.add(g);
        k.add(h);
        k.add(i);
        k.add(j);
        k.add(o);
        k.add(l);
        k.add(m);
        k.add(n);
        k.add(y);
        k.add(u);
        k.add(job);
        k.add(jobApplied);

        k.setSize(700, 700);
        k.setLayout(null);
        k.setVisible(true);

    }

}
