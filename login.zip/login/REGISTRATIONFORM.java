package login;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class REGISTRATIONFORM {

    Connection conn;
    dbHelper db = new dbHelper();

    REGISTRATIONFORM() {
        conn = db.conn;

        final JFrame k = new JFrame("REGISTRATION FORM");
        JLabel a1 = new JLabel("FULL NAME");
        a1.setBounds(20, 30, 170, 30);
        final JTextField b = new JTextField();
        b.setBounds(200, 30, 350, 30);
        JLabel c = new JLabel("GENDER");
        c.setBounds(20, 70, 170, 30);
        final JTextField d = new JTextField();
        d.setBounds(200, 70, 350, 30);
        JLabel e = new JLabel("AGE");
        e.setBounds(20, 110, 170, 30);
        final JTextField f = new JTextField();
        f.setBounds(200, 110, 350, 30);
        JLabel g = new JLabel("LEVEL OF EDUCATION");
        g.setBounds(20, 150, 170, 30);
        final JTextField h = new JTextField();
        h.setBounds(200, 150, 350, 30);
        JLabel i = new JLabel("PHONE NUMBER");
        i.setBounds(20, 190, 170, 30);
        final JTextField j = new JTextField();
        j.setBounds(200, 190, 350, 30);
        JLabel l = new JLabel("ID NUMBER");
        l.setBounds(20, 230, 170, 30);
        final JTextField m = new JTextField();
        m.setBounds(200, 230, 350, 30);
        final JLabel n = new JLabel("EMAIL");
        n.setBounds(20, 270, 170, 30);
        final JTextField o = new JTextField();
        o.setBounds(200, 270, 350, 30);
        JLabel p1 = new JLabel("PASSWORD");
        p1.setBounds(20, 310, 170, 30);

        final JPasswordField q = new JPasswordField();
        q.setBounds(200, 310, 350, 30);
        JLabel r = new JLabel("CONFIRM PASSWORD");
        r.setBounds(20, 350, 170, 30);
        final JPasswordField s = new JPasswordField();
        s.setBounds(200, 350, 350, 30);
        JButton t = new JButton("CLEAR");
        t.setBounds(20, 390, 170, 30);
        JButton u = new JButton("SUBMIT");
        u.setBounds(200, 390, 170, 30);
        JButton y = new JButton("HELP");
        y.setBounds(200, 450, 170, 30);
        JButton z = new JButton("Go Back");
        z.setBounds(20, 450, 170, 30);
        z.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent y) {
                k.dispose();
            }
        });
        y.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent y) {

                JOptionPane.showMessageDialog(n, "FOR ANY ASSISTANCE CONTACT 0713230857!", "CUSTOMER CARELINE!", 1);
            }
        });
        u.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent y) {
                // Getting values from the fields
                String idNo = null;
                Integer age = null;
                String name = b.getText();
                String gender = d.getText();
                String eduLevel = h.getText();
                String pNo = null;
                String email = o.getText();
                String password = q.getText();
                String cPassword = s.getText();
                Verifier verify = new Verifier();
                // Check if any field is empty
                if (name.isEmpty() || gender.isEmpty() || eduLevel.isEmpty() || email.isEmpty()
                        || password.isEmpty() || cPassword.isEmpty() || m.getText().isEmpty() || f.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(k, "Please fill all the empty fields");
                } else {

                    if (verify.stringVerifier(name)) {
                        if (!verify.stringVerifier(name)) {
                            JOptionPane.showMessageDialog(k, "Invalid fullname");
                            return;
                        }
                        if (!verify.stringVerifier(gender)) {
                            JOptionPane.showMessageDialog(k, "Invalid gender");
                            return;
                        }

                        if (!verify.stringVerifier(eduLevel)) {
                            JOptionPane.showMessageDialog(k, "Invalid education level");
                            return;
                        }
                        if (!verify.stringVerifier(email)) {
                            JOptionPane.showMessageDialog(k, "Invalid email");
                            return;
                        }

                        if (verify.verifyEmail(k, email)) {

                            try {
                                // Parse ID Number and Age (if they are valid numbers)
                                idNo = m.getText();
                                age = Integer.parseInt(f.getText());
                                pNo = j.getText();
                                if (!idNo.matches("[0-9]+")) {
                                    JOptionPane.showMessageDialog(k, "ID Number must contain only digits", "Invalid ID Number", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }
                                if (!pNo.matches("[0-9]+")) {
                                    JOptionPane.showMessageDialog(k, "Phone number must contain only digits", "Invalid Phone Number", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }

                                // Validate the age to be between 18 and 99
                                if (age < 18 || age >= 100) {
                                    JOptionPane.showMessageDialog(k, "Aplicant Must have 18 years and Above", "NOT ELIGIBLE", 2);
                                    return; // Exit the method
                                }
                                // Check if the passwords match
                                if (verify.matchPasswords(k, password, cPassword) && verify.verifyPassword(k, password)) {
                                    if (verify.verifypNo(k, pNo)) {
                                        if (verify.verifyidNo(k, idNo)) {
                                            submit(k, idNo, name, gender, age, eduLevel, pNo, email, password);
                                        }
                                    }
                                }
                            } catch (NumberFormatException e) {
                                // Handle case where ID or Age is not a valid number
                                JOptionPane.showMessageDialog(k, "Please enter valid numbers for ID and Age");
                            }

                        }
                    } else {
                        // Handle case when they are not strings
                        JOptionPane.showMessageDialog(k, "Please enter valid Full Name!", "INAVALID INPUT", 0);

                    }
                }
            }

        });
        t.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent y) {
                b.setText(null);
                d.setText(null);
                f.setText(null);
                h.setText(null);
                j.setText(null);
                m.setText(null);
                o.setText(null);
                q.setText(null);
                s.setText(null);

            }
        });
        k.add(a1);
        k.add(b);
        k.add(c);
        k.add(d);
        k.add(e);
        k.add(f);
        k.add(g);
        k.add(h);
        k.add(i);
        k.add(j);
        k.add(o);
        k.add(l);
        k.add(m);
        k.add(n);
        k.add(p1);
        k.add(q);
        k.add(r);
        k.add(s);
        k.add(t);
        k.add(u);
        k.add(y);
        k.add(z);
        k.setLayout(null);
        k.setSize(600, 600);
        k.setVisible(true);
    }

    private void submit(JFrame k, String idNo, String name, String gender, Integer age, String eduLevel, String pNo, String email, String password) {
        try {
            // First, check if the ID already exists
            String checkQuery = "SELECT COUNT(*) FROM Members WHERE idNumber = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setString(1, idNo);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                int count = rs.getInt(1);
                if (count > 0) {
                    // ID already exists in the database
                    JOptionPane.showMessageDialog(k, "ID Number already exists. Please use a different ID.", "Error", JOptionPane.ERROR_MESSAGE);
                    return; // Exit the method without inserting the data
                }
            }
            String query = "INSERT INTO Members (idNumber,Name,Gender,Age,educationLevel,pNumber,Email,password) VALUES(?,?,?,?,?,?,?,?)";
            PreparedStatement stm = conn.prepareStatement(query);
            stm.setString(1, idNo);
            stm.setString(2, name);
            stm.setString(3, gender);
            stm.setInt(4, age);
            stm.setString(5, eduLevel);
            stm.setString(6, pNo);
            stm.setString(7, email);
            stm.setString(8, password);

            int rows_affected = stm.executeUpdate();
            if (rows_affected > 0) {
                k.dispose();
                JOptionPane.showMessageDialog(k, "LOGIN FOR JOB APPLICATION!", "Registration successful", 1);

            } else {
                JOptionPane.showMessageDialog(k, "Please try again!", "Registration Failed", 0);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(k, "Please try again!", "Registration Failed", 0);
            e.printStackTrace();
        }
    }

}
