package login;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class LOGIN{
    String username,gender,eduLevel,email,password,g1;
    int age,pNo,idNo;
    // Variables for countdown timer
    private int timeRemainingInSeconds = 86400; // 1 day = 86400 seconds (set as default 1 day countdown)
    private Timer countdownTimer;
    private JLabel timerLabel;

LOGIN(){

final JFrame n = new JFrame("LOGIN FORM");
final JButton k = new JButton("FULL NAME");
final JButton p = new JButton("PASSWORD RECOVERY");
p.setBounds(70,230,180,30);

k.setBounds(20,30,120,30);
final JTextField h = new JTextField();
h.setBounds(150,30,190,30);
final JButton l= new JButton("PASSWORD");
l.setBounds(20,80,120,30);
final JPasswordField m = new JPasswordField();
m.setBounds(150,80,190,30);
JButton o= new JButton("LOGIN");
o.setBounds(50,180,100,30);
JButton y = new JButton("REGISTER");
y.setBounds(170,180,100,30);
 
// Timer label to display countdown
        timerLabel = new JLabel("Time Remaining For Job Application: " + formatTime(timeRemainingInSeconds));
        timerLabel.setBounds(20, 270, 300, 30);
        n.add(timerLabel);

y.addActionListener(new ActionListener(){
    public void actionPerformed(ActionEvent y ){
        
        new REGISTRATIONFORM();
    }});

p.addActionListener(new ActionListener(){
    public void actionPerformed(ActionEvent y ){
      
         
                     JOptionPane.showMessageDialog(n, "CALL:0793841592!","FOR PASSWORD RECOVERY",1);
    }});
o.addActionListener(new ActionListener(){
    public void actionPerformed(ActionEvent y ){
        username= h.getText();
         String password = m.getText();
         
         if(verify(n,username,password)){new jobApplication(username,gender,age,eduLevel,pNo,idNo,email,password); }
         else{ JOptionPane.showMessageDialog(n, "Invalid Username or password");}
         
         
        
    }
});
 // Start the countdown timer when the login form is shown
        startCountdown();

 n.add(k);
 //n.add(y);
  n.add(h);
   n.add(l);
    n.add(m);
     n.add(o);
     n.add(y);
     n.add(p);
   
      n.setSize(600,600);
      n.setLayout(null);
         n.setVisible(true);
}

 public static void main(String[] args) {
      new LOGIN();
    }
    
 
 

    private boolean verify(JFrame n,String username, String password) {
          boolean success=false;
          try{
               Connection conn;
                dbHelper db=new  dbHelper();
                conn=db.conn;
              
                //try to find a matching user from db
                String query="SELECT * FROM members WHERE (Name=? AND password=?)";
                PreparedStatement stm=conn.prepareStatement(query); //to prevent sql injection
                stm.setString(1, username);
                stm.setString(2, password);
                
                //execute the query
               ResultSet results=stm.executeQuery();
                
              //check if results were found from db
                if(results.next()){
                    gender=results.getString("Gender");
                    eduLevel=results.getString("educationLevel");
                    email=results.getString("Email");
                    idNo=results.getInt("idNumber");
                    pNo=results.getInt("pNumber");
                    age=results.getInt("Age");
                   g1=results.getString("name");
                       
                    success= true;
                }else{
                    success=false;
                }
               

            }catch(Exception e){
                 JOptionPane.showMessageDialog(n, "Please try again!","Login Failed",0);
                  success=false;
                e.printStackTrace();
            }
        return success;
        
     }
    // Method to start the countdown timer
    private void startCountdown() {
        // Timer that updates every second
        countdownTimer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Decrease time by 1 every second
                timeRemainingInSeconds--;

                // Update the timer label to show time in days:hours:minutes:seconds format
                timerLabel.setText("Time Remaining For Job Application: " + formatTime(timeRemainingInSeconds));

                // When time reaches 0, stop the timer and close the login window
                if (timeRemainingInSeconds <= 0) {
                    countdownTimer.stop();
                    JOptionPane.showMessageDialog(null, "Time is up! Closing login form.");
                    System.exit(0); // Close the application or you can dispose the frame here.
                }
            }
        });

        countdownTimer.start();
    }

    // Method to convert time in seconds to a formatted string: Days:Hours:Minutes:Seconds
    private String formatTime(int timeInSeconds) {
        int days = timeInSeconds / 86400; // 1 day = 86400 seconds
        int hours = (timeInSeconds % 86400) / 3600; // 1 hour = 3600 seconds
        int minutes = (timeInSeconds % 3600) / 60; // 1 minute = 60 seconds
        int seconds = timeInSeconds % 60;

        return String.format("%02d:%02d:%02d:%02d", days, hours, minutes, seconds);
    }
}
